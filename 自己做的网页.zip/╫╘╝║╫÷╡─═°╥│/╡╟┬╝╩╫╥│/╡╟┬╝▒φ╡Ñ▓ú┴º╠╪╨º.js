window.onload = function() {
  //表单验证
  var denlu = document.getElementById("dengr");
  var youhui = document.getElementById("youhui");
  var mima = document.getElementById("mima");
  var buttom = document.getElementById("button");
  buttom.addEventListener("click", function() {
    if (youhui.value == "" && mima.value == "") {
      denlu.innerHTML = "用户名或密码不能为空";
    } else if (youhui.value != "" && mima.value == "") {
      denlu.innerHTML = "密码不能为空";
    } else if (youhui.value == "" && mima.value != "") {
      denlu.innerHTML = "用户名不能为空";
    } else {
      window.location.href = "https://www.bilibili.com/";
    }
  });
  //切换背景
  var btns = document.querySelector(".tup").querySelectorAll("img");
  var con = document.querySelector(".container");
  for (var i = 0; i < btns.length; i++) {
    btns[i].onclick = function() {
      // this.src;
      con.style.backgroundImage = "url(" + this.src + ")"; //改变背景图
    };
  }
  //时间
  var sh = document.getElementById("sh");
  var yue = document.getElementById("yue");
  var shij = new Date();

  function showDate() {
    var today = new Date();
    var date =
      today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    sh.innerHTML = date;
  }

  setInterval(showDate); //不停地调用函数
  yue.innerHTML =
    shij.getFullYear() +
    "年" +
    (shij.getMonth() + 1) +
    "月" +
    shij.getDate() +
    "日";
};
